<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MSA</title>
    <style type="text/css">

    </style>
</head>
<body>

<?php

include ("./header.php");

?>

<?php

if(isset($_POST["submit"])){
    echo "<pre>";
    print_r($_POST);
}

?>


</body>
</html>
